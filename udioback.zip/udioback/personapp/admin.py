from django.contrib import admin
from . models import person
# Register your models here.

admin.site.register(person)
