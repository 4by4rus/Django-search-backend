from django.shortcuts import render

from django.http import HttpResponse
from django.http import HttpRequest
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import filters
from django.db.models import Q
from django.shortcuts import render, get_object_or_404, redirect
from rest_framework.views import APIView
from rest_framework.generics import ListAPIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework import generics
from rest_framework.renderers import TemplateHTMLRenderer
from . models import person
from .forms import personform

from . serializers import personSerializer


# Create your views here.

class personList(APIView):


    def get(self, request):
        person1 = person.objects.all()
        serializer = personSerializer(person1, many=True)
        return Response(serializer.data)
        # return render(request, "personlist.html", context)


class personDetail(APIView):
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'personlist.html'

    def get(self, request):
        # person1 = get_object_or_404(person, pk=pk)
        person1 = person.objects.all()
        serializer = personSerializer(person1, many=True)
        return Response({'persons': person1})


class personListSearchView(ListAPIView):
    renderer_classes = [TemplateHTMLRenderer]
    template_name = 'searchlist.html'


    def get(self, request):
        # person1 = person.objects.all()
            person1 = person.objects.all()
            query = request.GET.get("q")
            if query:
                person1 = person1.filter(
                    Q(personname__icontains=query) |
                    Q(personemail__icontains=query)
                ).distinct()
                return Response({'persons': person1})
            else:
                return Response({'persons': person1}) # I wanted to send back json when I use angular but dont know how atm


class personListSearchViewJson(ListAPIView):
   serializer_class = personSerializer

   def get_queryset(self, *args, **kwargs):
        person1 = person.objects.all()

        response = Response()
        response['Cache-Control'] = 'no-cache'
        response['Access-Control-Allow-Origin'] = '*'
        response['Access-Control-Allow-Methods']: 'GET, POST, OPTIONS, PUT, PATCH, DELETE'
        response['Access-Control-Allow-Headers']: 'X-Requested-With,content-type'
        response['Access-Control-Allow-Credentials']: True

        query = self.request.GET.get("q")
        if query:
                person1 = person1.filter(
                    Q(personname__icontains=query) |
                    Q(personemail__icontains=query)
                ).distinct()
                # return person1
        return person1

class personCreate(APIView):

    def person_create(request):
                form = personform(request.POST or None)  #adding request.POST adds auto validation, so doesnt need below if cond. to check

                if form.is_valid():
                    instance = form.save(commit=False)
                    instance.save()
                    return redirect("/persons/listdetail")
                context = {
                    "form": form,
                }
                return render(request,"personform.html", context)


