from django.db import models

# Create your models here.
class person(models.Model):
    personname=models.CharField(max_length=20)
    personemail=models.EmailField(max_length=40)
    personid=models.IntegerField()

    def __str__(self):
        return self.personname